#ifndef COMMON_H
#define COMMON_H

#define WINVER 0x0601 /*API Windows 7*/
#include <Windows.h>
#include <iostream>


#endif