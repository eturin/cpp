BC - SAP Automation (HTMLHELP)
==============================

To add the submenu "SAP Automation (HTMLHelp)" to your "Start -> Programs" menu:

1. In Windows Explorer select the file
   \Htmlhelp\english\Hhmenuen.inf.
2. Press the right mouse button and choose "Install".

A submenu with shortcut "BC - SAP Automation" is included in the Windows "Start ->
Programs" menu.

If you prefer not to include these shortcuts in your "Start -> Programs" menu,
select the file <Drive>:\Htmlhelp\english\00000001.chm in
Windows Explorer and double-click. This will open the SAP Automation Documentation
and you can navigate from there.