BC - SAP Automation (HTMLHELP)
==============================

The HTML Help Viewer is the software that lets you read the SAP Automation Help files. 

You may need to install the HTML Help Viewer if:

* You do not have an HTML Help Viewer at all

* You experience problems when reading the Help files, for example, if you are getting errors when attempting to use some of the links. This may be a result of an incompatible version of the HTML Help Viewer.

To install the HTML Help Viewer, double-click on the Hhupd.exe file (provided in the HTMLHELP_Viewer directory).